<!doctype html>
<html lang="en">
<style>
    .qqq ul li{
        list-style: none;
        float: left;
        padding: 0 15px;
    }
</style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery.js"></script>
</head>
<body>

<select name="is_show" style="margin:0 20px">
    <option value="0">请选择</option>
    <option value="1">上架</option>
    <option value="2">已下架</option>
</select>
<select name="is_hot" style="margin:0 20px">
    <option value="0">请选择</option>
    <option value="1">热卖</option>
    <option value="2">非热卖</option>
</select>
<input type="button" name="search" value="搜索" style="margin:0 20px">

<form class="add_form">
    <table border="1">
        <tr>
            <td>商品id</td>
            <td>名称</td>
            <td>分类</td>
            <td>描述</td>
            <td>是否热卖</td>
            <td>是否上架</td>
            <td>操作</td>
        </tr>
        <?php foreach($arr as $k=>$v){?>
        <tr>
            <td><?php echo e($v->id); ?></td>
            <td><input type="text" value="<?php echo e($v->name); ?>" id="<?php echo e($v->id); ?>" class="name"></td>
            <td><?php echo e($v->c_name); ?></td>
            <td><?php echo e($v->desc); ?></td>
            <td><?php echo e($v->is_hot); ?></td>
            <td><?php echo e($v->is_show); ?></td>
            <td> <a href="update?id=<?php echo e($v->id); ?>">修改</a>
                <a href="javascript:;" name="del" id="<?php echo e($v->id); ?>">删除</a></td>
        </tr>
        <?php }?>
    </table>
    <div class='qqq'><?php echo e($arr->links()); ?></div>
</form>
</body>
</html>
<script src="/js/jquery.js"></script>
<script>
    $(function(){
        $("[name='del']").click(function(){
            var _this=$(this);
            var goods_id=_this.attr('id');
            if(confirm('是否删除？')){
                $.post('delete',{id:goods_id},function(res){
                    if(res==1){
                        alert('删除成功');
                        _this.parents('tr').remove();
                    }else{
                        alert('删除失败');
                    }
                });
            }
        });

        $('.name').blur(function(){
        var str=$(this).val();
        var obj=$(this);
        var id=$(this).attr('id');
        $.ajax({
            method: "POST",
            url: "upname",
            data: 'name='+str+'&id='+id,
        }).done(function( msg ) {
            console.log(msg);
            if(msg==1){
                alert('修改成功');
                history.go(0);
            }else{
                alert('修改失败');
            }
        });
    });


        
    })
</script>