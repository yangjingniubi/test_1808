<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class index extends Model
{
    
    protected $table = 'user';
    //public $timestamps=false;
} 
