<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class user extends Model
{
    
    protected $table = 'shop';
    public $timestamps=false;
} 
