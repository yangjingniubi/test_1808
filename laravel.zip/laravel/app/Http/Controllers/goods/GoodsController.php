<?php

namespace App\Http\Controllers\goods;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class GoodsController extends Controller
{
    public function detail(Request $request){
    	$g_id=$request->input('id');
    	$where=[
    		'goods_id'=>$g_id
    	];
    	$goodsInfo=DB::table('goods')->where($where)->get();



        $id = session("name");
        $Awhere=[
            'user_id'=>$id,
            'status'=>1
        ];
        $Acount=DB::table('cart')->where($Awhere)->select('number')->get();
        $num=[];
        foreach ($Acount as $k=>$v){
            $num[]=$v->number;
        }
        $count=array_sum($num);
    	return view("goods.content",['goodsInfo'=>$goodsInfo,'count'=>$count]);
    }

    public function cart(){
        $awhere=[
            'status'=>1
        ];
    	$arrInfo=DB::table('cart')->join('goods','goods.goods_id','=','cart.goods_id')->where($awhere)->get();
    	//print_R($arrInfo);
        $bwhere=[
            'is_tell'=>3
        ];
        $cartInfo=DB::table('goods')->where($bwhere)->paginate(4);
    	return view("goods.cart",['arrInfo'=>$arrInfo,'cartInfo'=>$cartInfo]);
    }

    // public function cartadd(Request $request){
    // 	$id=$request->input('id');
    // 	$time=time();
    // 	$arr=array(
    // 		'goods_id'=>$id,
    // 		'user_id'=>session("name"),
    // 		'ctime'=>$time
    // 	);
    // 	$arr=DB::table('cart')->insert($arr);
    // 	if(!empty($arr)){
    // 		$arr=array(
    // 			'status'=>1,
    //             'msg'=>'添加成功'
    //         );
    //         return $arr;
    // 	}
    // }

    public function cartadd(Request $request){
        $goods_id=$request->input('id');
        $arr=DB::table('goods')->where('goods_id',$goods_id)->first();
        if($arr){
            $id = session("name");
            if(empty($id)){
                echo json_encode([
                    'msg'=>1,
                    'font'=>'您没有登录'
                ]);
            }else{
                $is_sell=$arr->is_sell;
                if($is_sell!=1){
                    echo json_encode([
                        'msg'=>1,
                        'font'=>'没有此商品'
                    ]);
                }else{
                    $where=[
                        'goods_id'=>$goods_id,
                        'user_id'=>$id,
                        'status'=>1
                    ];
                    $cart= DB::table('cart')->where($where)->first();
                    if($cart){
                        $number=$cart->number;
                        $num=$number+1;
                        $goods_num=$arr->goods_num;
                        if($num>$goods_num){
                            echo json_encode([
                                'msg'=>1,
                                'font'=>'库存不足'
                            ]);
                        }else{
                            $cart= DB::table('cart')->where($where)->update(['number'=>$num]);
                            echo json_encode([
                                'msg'=>0,
                                'font'=>'添加成功'
                            ]);
                        }
                    }else{
                        $data=[];
                        $data['goods_id']=$goods_id;
                        $data['user_id']=$id;
                        $data['number']=1;
                        $data['ctime']=time();
                        DB::table('cart')->insert($data);
                        echo json_encode([
                            'msg'=>0,
                            'font'=>'添加成功'
                        ]);
                    }
                   
                }
            }
        }else{
            echo json_encode([
                'msg'=>1,
                'font'=>'没有该商品'
            ]);
        }
    }

    public function cart_del(Request $request){
        $cart_id=$request->input('cart_id');
        $arr=DB::table('cart')->whereIn('cart_id',$cart_id)->update(['status'=>0]);
        //dump($arr);exit;
        if($arr){
            return $info = [
                'status' => 1,
                'msg' => '删除成功'
            ];
        }else{
            return $info = [
                'status' => 0,
                'msg' => '删除失败'
            ];
        }
    }

      
        //加减改变商品数量
        public function updateNum(Request $request){
            $data=$request->input();
            $cart_id=$data['cart_id'];
            $num=$data['num'];
            if($num<1){
                $res=DB::table('cart')->where('cart_id','=',$cart_id)->update(['number'=>1]);
            }else{
                $res=DB::table('cart')->where('cart_id','=',$cart_id)->update(['number'=>$num]);
            }
            
        }

        

}
