<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\models\user;

class UserController extends Controller
{
    

    // public function index(Request $Request){
    // 	$id=$Request->input('id');
    // 	$name=$Request->input('name');
    // 	echo $id;
    // 	echo $name;
    // }

    // public function show(Request $Request){
    	// $sql="insert into user set name='yang'";
    	// $arr=DB::insert($sql);
    	// print_R($arr);

		//	$sql="update user set name='yangjing' where id='1'";
  		//	$arr=DB::update($sql);
  		//	print_R($arr);  
  		

  		// $sql="select * from user";
    	// 	$arr=DB::select($sql);
    	// 	print_R($arr);	
     	
        //   $sql="delete  from user where id=2";
      		// $arr=DB::delete($sql);;p
      		// print_R($arr);
    
    // }

    public function orm(){
      //查
      // $arr=user::all(); first()
      // print_R($arr);exit;
      
      //增
      // $name=array(
      //   'name'=>'好',
      //   'c_id'=>1,
      //   'desc'=>'aaaaaa',
      //   'is_hot'=>2,
      //   'is_show'=>2
      // );
      // $res=user::insert($name);
      // echo $res;
      
      //删
      // $id=7;
      // $res=user::where('id','=',$id)->delete();
      // echo $res;
      
      //修改
      // $id=2;
      // $arr=array('name'=>'liddd');
      // $res=user::where('id','=',$id)->update($arr);
      // echo $res;
    }

    public function add(){
      $arr=DB::table('cate')->get();
      return view('user.User',['cate'=>$arr]);
    }

    public function doadd(Request $request){
      $data=$request->input();
      $insert_data['name']=rtrim($data['name']);
      $insert_data['c_id']=intval($data['c_id']);
      $insert_data['desc']=rtrim($data['desc']);
      $insert_data['is_hot']=intval($data['is_hot']);
      $insert_data['is_show']=intval($data['is_show']);
      $res=DB::table('shop')->insert($insert_data);
      if($res){
        echo 1;
      }else{
        echo 2;
      }
    }

    //展示
    public function show(){
        $arr=DB::table('shop')->join('cate','cate.c_id','=','shop.c_id')->paginate(3);
        foreach($arr as $k=>$v){
            if($v->is_hot==1){
              $arr[$k]->is_hot='√';
            }else{
              $arr[$k]->is_hot='×';
            }

            if($v->is_show==1){
              $arr[$k]->is_show='√';
            }else{
              $arr[$k]->is_show='×';
            }
        }
        return view('user.show',['arr'=>$arr]);
    }


    //删除
    public function delete(Request $request){
        $goods_id=$request->input('id');
        $res=DB::table('shop')->where('id',$goods_id)->delete();
        if($res){
            return 1;
        }else{
            return 2;
        }
    }

    //修改
    public function update(Request $request){
        $cate_info=DB::table('cate')->get();
        $id=$request->input('id');
        $arr=DB::table('shop')->where('id',$id)->first();
        return view('user.update',['arr'=>$arr,'cate'=>$cate_info]);
    }

    public function update_do(Request $request){
        $data=$request->input();
        $id=$data['id'];
        $res=DB::table('shop')->where('id',$id)->update($data);
        if($res){
            return 1;
        }else{
            return 2;
        }
    }

    public function upname(Request $request){
        $name=$request->input('name');
        $id=$request->input('id');
        $res=DB::table('shop')->where('id',$id)->update(['name'=>$name]);
        if($res){
            echo  1;
        }else{
            echo 2;
        }
    }

}
