<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\models\index;

class IndexController extends Controller
{
    public function index(){
        $where=[
            'is_tell'=>1
        ];
        $goods=DB::table('goods')->where($where)->paginate(2);
    	return view('index.index',['cate'=>$goods]);
    }

    public function userpage(){
    	return view("index/userpage");
    }

    public function set(Request $request){
    	return view('index/set');
    }
    public function quit(Request $request){
        $request->session()->flush();
    }

    public function login(){
    	return view('index/login');
    } 

    public function dologin(Request $request){
        $arr=$request->input();
        $name=$arr['name'];
        $pwd=$arr['pwd'];
        $pwd=md5($pwd);

        $data=['name'=>$name,'pwd'=>$pwd];
        $user=DB::table('user')->where($data)->first();

        if($user){
            $id=$user->id;
            $name=$user->name;
            session(['id'=>$id,'name'=>$name]);
            $arr=array(
                'status'=>1,
                'msg'=>'登陆成功'
            );
            echo json_encode($arr);
        }else{
            $arr=array(
                'status'=>0,
                'msg'=>'账号或密码错误'
            );
            echo json_encode($arr);
        }
    }

    public function register(){
    	return view('index/register');
    }

    public function doadd(Request $request){
        $arr=$request->input();
        $tel=$arr['tel'];
        $pwd=$arr['pwd'];
        $conpwd=$arr['conpwd'];
        $code=$arr['code'];
        if($pwd!=$conpwd){
            $arr=array(
                'status'=>0,
                'msg'=>'请您再次输入密码！'
            );
            return $arr;
        }
        if(empty($pwd)){
            $arr=array(
                'status'=>0,
                'msg'=>'请输入您的密码'
            );
            return $arr;
        }
        //验证唯一
        $arr=index::where('name',$tel)->first();
        if(!empty($arr)){
            $arr=array(
                'status'=>0,
                'msg'=>'号码已存在'
            );
            return $arr;
        }
        //验证验证码
        $time=time();
        $arrInfo=DB::table("code")->select("*")->where("code",$code)->where("timeout",">",$time)->where("tel",$tel)->where("status",1)->first();
        if(empty($arrInfo->id)){
            $arr=array(
                'status'=>0,
                'msg'=>'验证码错误',
            );
            return $arr;
        }
        $id=$arrInfo->id;

        $pwd=md5($pwd);
        $arrInfo=array(
            'name'=>$tel,
            'pwd'=>$pwd
        );
        $bol=DB::table('user')->insert($arrInfo);
        if($bol){
            $arr=array(
                'status'=>1,
                'msg'=>'注册成功'
            );
            echo json_encode($arr);
            DB::table("code")->where('id',$id)->update(['status'=>0]);
        }else{
            $arr=array(
                'status'=>0,
                'msg'=>'注册失败'
            );
            echo json_encode($arr);
        }
    }

    public function getcode(Request $request){
        $tel=$request->input("tel");
        $num = rand(1000,9999);
        $obj=new\send();
        $bol=$obj->show($tel,$num);
        if($bol==100){
            $arr=array(
                'tel'=>$tel,
                'code'=>$num,
                'timeout'=>time()+180,
                'status'=>1,
            );
            $bol=DB::table('code')->insert($arr);
        }
    }


    public function addli(Request $request){
        $arr=array();
        $page=$request->input("page",1);
        $pageNum=4;
        $offset=($page-1)*$pageNum;
        $arrDataInfo=DB::table('goods')->offset($offset)->limit($pageNum)->get();

        $totalData=DB::table('goods')->count();
        $pageTotel=ceil($totalData/$pageNum);

        $objview=view("index.goodsali",['info'=>$arrDataInfo]);
        $content=response($objview)->getContent();


        $arr['info']=$content;
        $arr['page']=$pageTotel;

        return $arr;

    }


    public function buyrecord(){
        $bwhere=[
            'is_tell'=>3
        ];
        $cartInfo=DB::table('goods')->where($bwhere)->paginate(4);
        return view('index.buyrecord',['cartInfo'=>$cartInfo]);
    }

}
