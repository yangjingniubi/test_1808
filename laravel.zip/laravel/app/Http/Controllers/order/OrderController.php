<?php

namespace App\Http\Controllers\order;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\models\CartModel;

class OrderController extends Controller
{
    //提交结算
   public function paymentAdd(Request $request){
        $user_id=session('id');
        if(empty($user_id)){
            echo json_encode(['code'=>2,'msg'=>'请先登录！']);
            die;
        }
        $data=$request->input('goods_id');
        if(!empty($data)){
          $cart=CartModel::whereIn('cart_id',$data)->join('goods','goods.goods_id','=','cart.goods_id')->select('*')->get()->toArray();
          //dump($cart);die;
          foreach ($cart as $k=>$v){
              if($v['number']>$v['goods_num']){
                $all[]=$v['goods_name'];
              }
              $goodsIds[]=$v['goods_id'];
          }
          if(!empty($all)){
              echo json_encode(['code'=>0,'msg'=>implode(',',$all).'----这些商品的库存不足,请先减少购买数量']);
          }
          foreach($cart as $k=>$v){
              if($v['is_sell']!=1){
                $add[]=$v['goods_name'];
              }
              //总金额
              $money[]=$v['goods_price']*$v['number'];
          }
            if(!empty($add)){
              echo json_encode(['code'=>0,'msg'=>'对不起，'.implode(',',$add).'----这些商品的已下架,请删除这些商品']);
            }
        }else{
          echo json_encode(['code'=>0,'msg'=>'请选择一件商品！']);
        }
        //订单号
        $order_sn=date("YmdHis",time()).rand(1000,9999);
        //print_r($order_sn);die;
        //添加进库
            $array=[
                'order_no'=>$order_sn,
                'user_id'=>$user_id,
                'order_amount'=>array_sum($money),
                'order_pay_type'=>1,
                'pay_status'=>1,
                'pay_way'=>1,
                'status'=>1,
                'ctime'=>time()
            ];
            $res=DB::table('order')->insertGetId($array);
            if(!empty($res)){
              DB::table('cart')->whereIn('cart_id',$data)->update(['status'=>0]);
              foreach ($cart as $k=>$v){
                  $arr[]=[
                      'order_id'=>$res,
                      'goods_id'=>$v['goods_id'],
                      'goods_name'=>$v['goods_name'],
                      'order_no'=>$order_sn,
                      'user_id'=>$user_id,
                      'buy_number'=>$v['number'],
                      'shop_price'=>$v['goods_price'],
                      'order_amount'=>array_sum($money),
                      'goods_img'=>$v['goods_img']
                  ];
               }
                $arr=DB::table('order_goods')->insert($arr);
                echo json_encode(['code'=>1,'msg'=>'成功...请稍后','order_id'=>$res]);
            }else{
                echo json_encode(['code'=>0,'msg'=>'添加失败','order_id'=>'']);
            }
   }
   public function order(Request $request){
      $order_id=$request->input('order_id');
      $user_id=$user_id=$request->session()->get('id');
      $where=[
        'order_id'=>$order_id,
        'user_id'=>$user_id
      ];
      $arr=DB::table('order_goods')->where($where)->get()->toArray();
      //dump($arr);die;
      $order_price=DB::table('order')->where($where)->get()->toArray()[0];
      // dump($order_price);die;
      return view("order.payment",['arr'=>$arr,'order_price'=>$order_price]);
   }

   public function address(Request $request){
      $order_id=$request->input();
      // echo $order_id;exit;
      // print_R($order_id);exit;
      $where=[
        'order_id'=>$order_id
      ];
      $arr=DB::table('order')->where($where)->value("address_id");
      //print_R($arr);exit;
      if(empty($arr)){
          echo json_encode(['code'=>0,'msg'=>'请选择收货地址',"id"=>$order_id['id']]);
      }
   }

   public function addressShow(Request $request){
      $order_id=$request->input("order_id");
      $user_id=session('id');
      $where=[
        'user_id'=>$user_id,
        'is_del'=>'1'
      ];
      $arrInfo=DB::table('order_address')->where($where)->get();
      return view("order/address",['arrInfo'=>$arrInfo,'order_id'=>$order_id]);
   }

   public function writeaddr(Request $request){
      $order_id=$request->input("order_id");
      return view("order/writeaddr",['order_id'=>$order_id]);
   }

   public function address_do(Request $request){
        $data=$request->input();
        $order_id=$data['order_id'];
        //dump($data);die;
        $user_id=$user_id=$request->session()->get('id');
        if(empty($user_id)){
            echo json_encode(['code'=>2,'msg'=>'请先登录！']);die;
        }
        $data['user_id']=$user_id;
        $data['ctime']=time();
        $res=DB::table('order_address')->insert($data);
        $address_id=DB::table('order_address')->where('order_id',$order_id)->value('address_id');
        if($res){
          if(!empty($order_id)){
            $arr=DB::table('order')->where('order_id',$order_id)->update(['address_id'=>$address_id]);
          }
            echo json_encode(['code'=>1,'msg'=>'添加成功']);
        }else{
            echo json_encode(['code'=>0,'msg'=>'添加失败']);
        }
    }

    public function  add_del(Request $request){
        $address_id=$request->input('address_id');
        $all=DB::table('order_address')->where('address_id',$address_id)->get()->toArray()[0];
        //dump($all);die;
        if($all->is_default==1){
            return json_encode([
                'code'=>0,
                'msg'=>'请先修改默认地址，再次删除'
            ]);
        }
        $res=DB::table('order_address')->where('address_id',$address_id)->update(['is_del'=>0]);
        if($res){
            return json_encode([
                'code'=>1,
                'msg'=>'删除成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'删除失败'
            ]);
        }
    }


    public function addressupdate(Request $request){
        $address_id=$request->input('address_id');
        // print_R($address_id);exit;
        $res=DB::table('order_address')->where('address_id',$address_id)->get();
        // print_R($res);exit;
        return view('order/addressupdate',['addressInfo'=>$res]);
    }

    public function address_update(Request $request){
        $data=$request->input();
        $address_id=$request->input("address_id");
        // print_r($order_id);exit;
        $data=[
          'consignee_name'=>$data['consignee_name'],
          'consignee_tel'=>$data['consignee_tel'],
          'address'=>$data['address'],
          'detailed_address'=>$data['detailed_address']
        ];
        $where=[
          'address_id'=>$address_id
        ];
        $res=DB::table('order_address')->where($where)->update($data);
        if($res){
            echo json_encode(['code'=>1,'msg'=>'修改成功']);
        }else{
            echo json_encode(['code'=>0,'msg'=>'修改失败']);
        }
    }


}
