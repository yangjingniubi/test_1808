<?php

namespace App\Http\Controllers\cate;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class cateController extends Controller
{
    public static $arr=[];
    public function cate(){
    	$where=[
            'pid'=>0
        ];
        $cate=DB::table('category')->where($where)->get();

        $catearr=DB::table('goods')->orderBy('goods_price','desc')->get();
    	return view("cate.all",['cate'=>$cate,'catearr'=>$catearr]);
    }


    public function cateadd(Request $request){
        $cate_id=$request->input('id');
        if(empty($cate_id)){
            $goodsInfo=DB::table('goods')->orderBy('goods_price','desc')->get();
        }else{
            $arrIds=DB::table('category')->select("cate_id")->where("pid",0)->get();
            $this->get($cate_id);
            array_unshift(self::$arr,$cate_id);
            $goodsInfo=DB::table('goods')->whereIn("cate_id",self::$arr)->orderBy('goods_price','desc')->get();
        }
       
        $view=view("cate.shopsli",['goodsInfo'=>$goodsInfo]);
        $content=response($view)->getContent();
        $arr['info']=$content;
        return $arr;
    }

    public function get($id){
        $arrNews=DB::table('category')->select("cate_id")->where("pid",$id)->get();
        if(count($arrNews)>0){
            foreach($arrNews as $key=>$value){
                $cateId=$value->cate_id;
                $arrids=$this->get($cateId);
            }
        }
        foreach($arrNews as $value){
            $cate_id=$value->cate_id;
            array_push(self::$arr,$cate_id);
        }
    }

}
