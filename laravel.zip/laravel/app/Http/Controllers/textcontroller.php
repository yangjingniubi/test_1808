<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class textcontroller extends Controller
{
   public function add(){
   		echo 'add方法';
   }

   public function show(){
   		echo 'show方法';
   }

   public function demo(){
   	$arr=array(
   		array('id'=>1,"name"=>'yangjing','age'=>18),
   		array('id'=>2,"name"=>'yangjing','age'=>22),
   		array('id'=>3,"name"=>'yangjing','age'=>15),
   		array('id'=>4,"name"=>'yangjing','age'=>21)
   	);

   	$arr1=array();
   	foreach($arr as $k=>$v){
   		$arr1[$v['age']]=$v  8;
   	}
   	print_r($arr1);


   	// return view("demo");
   }


}
