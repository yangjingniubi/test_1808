<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>商品修改</title>
</head>
<body>
<form class="add_form">
    <input type="hidden" name="id" value="{{$arr->id}}">
    <table border=1>
        <tr>
            <td>商品名称</td>
            <td><input type="text" name="name" value="{{$arr->name}}"></td>
        </tr>
        <tr>
            <td>商品分类</td>
            <td>
                <select name="c_id">
                    <option value="0">请选择</option>
                    @foreach($cate as $k=>$v)
                        <option value="{{$v->c_id}}" @if($v->c_id==$arr->c_id) selected @endif>{{$v->c_name}}</option>
                    @endforeach
                </select>
            </td>
        </tr>
        <tr>
            <td>商品描述</td>
            <td><textarea name="desc" >{{$arr->desc}}</textarea></td>
        </tr>
        <tr>
            <td>是否热卖</td>
            <td>
                <input type="radio" name="is_hot" value=1 @if($arr->is_hot==1) checked @endif>是
                <input type="radio" name="is_hot" value=2 @if($arr->is_hot==2) checked @endif>否
            </td>
        </tr>
        <tr>
            <td>是否上架</td>
            <td>
                <input type="radio" name="is_show" value=1 @if($arr->is_show==1) checked @endif>是
                <input type="radio" name="is_show" value=2 @if($arr->is_show==2) checked @endif>否
            </td>
        </tr>
        <tr>
            <td><input type="button" class="submit" value="修改"></td>
            <td></td>
        </tr>
    </table>
</form>
</body>
</html>
<script src="/js/jquery.js"></script>
<script>
    $(function(){
        $('.submit').click(function(){
            var form=$(".add_form").serialize();
            $.ajax({
                url:'update_do',
                data:form,
                method:'post',
                success:function(res){
                    if(res==1){
                        alert('修改成功');
                        location.href="show";
                    }else{
                        alert('修改失败');
                    }
                }
            });
        });
    })
</script>