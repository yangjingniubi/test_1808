<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>购物车</title>
    <meta content="app-id=518966501" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link href="css/cartlist.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="layui/css/layui.css">
    <script src="layui/layui.js"></script> 
</head>
<body id="loadingPicBlock" class="g-acc-bg">
    <input name="hidUserID" type="hidden" id="hidUserID" value="-1" />
    <div>
        <!--首页头部-->
        <div class="m-block-header">
            <a href="/" class="m-public-icon m-1yyg-icon"></a>
            <a href="/" class="m-index-icon">编辑</a>
        </div>
        <!--首页头部 end-->
        <div class="g-Cart-list">
            <ul id="cartBody">
                @foreach($arrInfo as $k=>$v)
                <li id="u-Cart-r" class="ap" >
                    <s class="xuan current" cart_id="{{$v->cart_id}}" goods_id="{{$v->goods_id}}"></s>
                    <a class="fl u-Cart-img" href="/v44/product/12501977.do">
                        <img src="img/{{$v->goods_img}}" border="0" alt="">
                    </a>
                    <div class="u-Cart-r">
                        <a href="/v44/product/12501977.do" class="gray6">{{$v->goods_name}}</a>
                        <span class="gray9">
                            <em>￥{{$v->goods_price}}</em>
                        </span>
                        <div class="num-opt">
                            <em class="num-mius dis min"><i></i></em>
                            <input class="text_box" name="num" maxlength="6" type="text" value="{{$v->number}}" codeid="12501977" goods_price="{{$v->goods_price}}" cart_id="{{$v->cart_id}}" goods_num="{{$v->goods_num}}">
                            <em class="num-add add"><i></i></em>
                        </div>
                        <a href="javascript:;" name="delLink" cart_id="{{$v->cart_id}}" cid="12501977" isover="0" class="z-del"><s></s></a>
                    </div>    
                </li>
                @endforeach
               
               
            </ul>
            <div id="divNone" class="empty "  style="display: none"><s></s><p>您的购物车还是空的哦~</p><a href="https://m.1yyg.com" class="orangeBtn">立即潮购</a></div>
        </div>
        <div id="mycartpay" class="g-Total-bt g-car-new" style="">
            <dl>
                <dt class="gray6">
                    <s class="quanxuan current"></s>全选
                    <p class="money-total">合计<em class="orange total"><span>￥</span>17.00</em></p>
                    
                </dt>
                <dd>
                    <a href="javascript:;" id="a_payment" class="orangeBtn w_account remove" name="remove">删除</a>
                    <a href="javascript:;" id="payment" class="orangeBtn w_account">去结算</a>
                </dd>
            </dl>
        </div>
        <div class="hot-recom">
            <div class="title thin-bor-top gray6">
                <span><b class="z-set"></b>人气推荐</span>
                <em></em>
            </div>
            <div class="goods-wrap thin-bor-top">
                <ul class="goods-list clearfix">
                    @foreach($cartInfo as $v)
                    <li>
                        <a href="https://m.1yyg.com/v44/products/23458.do" class="g-pic">
                            <img src="img/{{$v->goods_img}}" width="136" height="136">
                        </a>
                        <p class="g-name">
                            <a href="https://m.1yyg.com/v44/products/23458.do">{{$v->goods_name}}</a>
                        </p>
                        <ins class="gray9">价值:￥{{$v->goods_price}}</ins>
                        <div class="btn-wrap">
                            <div class="Progress-bar">
                                <p class="u-progress">
                                    <span class="pgbar" style="width:1%;">
                                        <span class="pging"></span>
                                    </span>
                                </p>
                            </div>
                            <div class="gRate" data-productid="23458">
                                <a href="javascript:;"><s></s></a>
                            </div>
                        </div>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>

       
        

<div class="footer clearfix">
    <ul>
        <li class="f_home"><a href="/v41/index.do" ><i></i>潮购</a></li>
        <li class="f_announced"><a href="/v41/lottery/" ><i></i>最新揭晓</a></li>
        <li class="f_single"><a href="/v41/post/index.do" ><i></i>晒单</a></li>
        <li class="f_car"><a id="btnCart" href="/v41/mycart/index.do" class="hover"><i></i>购物车</a></li>
        <li class="f_personal"><a href="/v41/member/index.do" ><i></i>我的潮购</a></li>
    </ul>
</div>

<script src="js/jquery-1.11.2.min.js"></script>
<!---商品加减算总数---->
    <script>
    // 全选        
    $(".quanxuan").click(function () {
        if($(this).hasClass('current')){
            $(this).removeClass('current');

             $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    $(this).removeClass("current"); 
                } else {
                    $(this).addClass("current");
                } 
            });
            GetCount();
        }else{
            $(this).addClass('current');

             $(".g-Cart-list .xuan").each(function () {
                $(this).addClass("current");
                // $(this).next().css({ "background-color": "#3366cc", "color": "#ffffff" });
            });
            GetCount();
        }
        
        
    });
    // 单选
    $(".g-Cart-list .xuan").click(function () {
        if($(this).hasClass('current')){
            

            $(this).removeClass('current');

        }else{
            $(this).addClass('current');
        }
        if($('.g-Cart-list .xuan.current').length==$('#cartBody li').length){
                $('.quanxuan').addClass('current');

            }else{
                $('.quanxuan').removeClass('current');
            }
        // $("#total2").html() = GetCount($(this));
        GetCount();
        //alert(conts);
    });
    //已选中的总额
    function GetCount() {
        var conts = 0;
        var aa = 0; 
        $(".g-Cart-list .xuan").each(function () {
            if ($(this).hasClass("current")) {
                for (var i = 0; i < $(this).length; i++) {
                    conts += parseInt($(this).parents('li').find('input.text_box').val()*$(this).parents('li').find('input.text_box').attr('goods_price'));
                    // aa += 1;
                }
            }
        });
        
         $(".total").html('<span>￥</span>'+(conts).toFixed(2));
    }
    GetCount();


            //商品加减算总数
            $(".add").click(function () {
                var t = $(this).prev();
                var num= t.attr('goods_num');
                t.val(parseInt(t.val()) + 1);
                if(t.val()<=parseInt(num)){
                    GetCount();
                    var cart_id= t.attr('cart_id');
                    change_num(t.val(),cart_id);
                }else{
                    alert('已达最大库存！');
                    t.val(parseInt(num));
                }
            });
            $(".min").click(function () {
                var t = $(this).next();
                if(t.val()>1){
                    t.val(parseInt(t.val()) - 1);
                    GetCount();
                    var cart_id= t.attr('cart_id');
                    change_num(t.val(),cart_id);
                }
            });
            //商品数量失焦
            $(document).on('blur','.text_box',function(){
                var _this=$(this);
                var num=parseInt(_this.val());
                var goods_num= _this.attr('goods_num');
                if(goods_num==0){
                    _this.val(0);
                    alert('该商品没有库存');
                }

                if( isNaN(num) ){
                    _this.val(1);
                }

                if(num<goods_num){
                    _this.val(num);
                }

                if(num>goods_num){
                    _this.val(goods_num);
                }

                if(num<1){
                    _this.val(1);
                }

                var cart_id= _this.attr('cart_id');
                change_num(num,cart_id);
            });

            function change_num(num,cart_id){
                var data={};
                data.num=num;
                data.cart_id=cart_id;
                $.post('updateNum',data,function(res){

                });
            }
</script>
</body>
</html>
<script>
    $(function () {
        layui.use('layer', function () {
            var layer = layui.layer;


            var cart_id=[];
            $("[name='delLink']").click(function () {
                var _this=$(this);
                $(this).each(function () {
                    for (var i = 0; i <1; i++) {
                        cart_id.push($(this).attr('cart_id'));
                    }
                });
                // console.log(cart_id);
                var url = 'cart_del';
                $.ajax({
                    type: 'post',
                    data: {cart_id: cart_id},
                    url: url,
                    dataType: 'json',
                    success: function (res) {
                        if(res.status==1) {
                            _this.parents('li').remove();
                            layer.msg(res.msg);
                        } else {
                            layer.msg(res.msg);
                        }
                    }
                })
            });


            //多删
            $("[name='remove']").click(function (){
                var cart_id=[];
                $(".g-Cart-list .xuan").each(function () {
                if($(this).hasClass("current")) {
                    for (var i = 0; i < $(this).length; i++) {
                        cart_id.push($(this).attr('cart_id'));
                    }
                }
            });
        
                // console.log(cart_id);
                // return false;
                var url='cart_del';
                $.ajax({
                    type:'post',
                    url:url,
                    dataType:'json',
                    data:{cart_id:cart_id},
                    success:function (res) {
                        if(res.status==1){
                            layer.msg(res.msg);
                            $(this).parents('#u-Cart-r').remove();
                            window.location.href="/cart";
                        }else{
                            layer.msg(res.msg);
                        }
                    }
                });
            });


            //结算payment
            $("#payment").click(function(){
                var goods_id=[];
                $(".g-Cart-list .xuan").each(function () {
                    if($(this).hasClass("current")) {
                        for (var i = 0; i < $(this).length; i++) {
                            goods_id.push($(this).attr('cart_id'));
                        }
                    }
                })
                // console.log(goods_id);
                // return false;
                var url='paymentAdd';
                $.ajax({
                    type:'post',
                    url:url,
                    dataType:'json',
                    data:{goods_id:goods_id},
                    success:function (msg) {
                        console.log();
                        if(msg.code==0){
                            layer.msg(msg.msg);
                        }else if(msg.code==1){
                            layer.msg(msg.msg);
                            window.location.href="/order?order_id="+msg.order_id;
                        }else if(msg.code==2){
                             layer.msg(msg.msg);
                            location.href='login';
                        }
                    }
                });
            })




        })
    })
</script>