<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
   	//echo 11111;
    return view('welcome');
});
Route::get('hello',function(){
	return 'Routes\web.php 中配置路由';
});

Route::get("user","user\usercontroller@add");

Route::get("add",function(){
	return view('user');
});


Route::get("shou/{id}",function($id){
	if($id<5){
		return redirect("http://www.baidu.com");
	}else{
		echo 'no';
	}
});

Route::get("demo","user\UserController@index");

Route::get("orm","user\UserController@orm");

Route::get("add","user\usercontroller@show");

Route::get("add","user\usercontroller@add");

Route::post("doadd","user\usercontroller@doadd");

Route::get("show","user\usercontroller@show");

Route::post("delete","user\usercontroller@delete");

Route::get("update","user\usercontroller@update");
Route::post("update_do","user\usercontroller@update_do");
Route::post("upname","user\usercontroller@upname");

Route::get("index","Index\IndexController@index");

Route::get("add","textController@add");
Route::get("t1","Index\IndexController@t1");

Route::get("show","textController@show");


Route::get("demo","textController@demo");

Route::get("userpage","Index\IndexController@userpage")->middleware('login');
Route::get("set","Index\IndexController@set");
Route::get("quit","Index\IndexController@quit");
Route::get("login","Index\IndexController@login");
Route::get("register","Index\IndexController@register");
Route::post("doadd","Index\IndexController@doadd");
Route::post("dologin","Index\IndexController@dologin");
Route::post("getcode","Index\IndexController@getcode");
Route::get("buyrecord","Index\IndexController@buyrecord");


Route::post("addli","Index\IndexController@addli");

Route::get("detail","goods\GoodsController@detail");
Route::get("cart","goods\GoodsController@cart");
Route::post("cart_del","goods\GoodsController@cart_del");
Route::post("cartadd","goods\GoodsController@cartadd");
Route::post("updateNum","goods\GoodsController@updateNum");



Route::post("paymentAdd","order\OrderController@paymentAdd");
Route::get("order","order\OrderController@order");
Route::post("address","order\OrderController@address");
Route::get("addressShow","order\OrderController@addressShow");
Route::get("writeaddr","order\OrderController@writeaddr");
Route::post("address_do","order\OrderController@address_do");
Route::post("add_del","order\OrderController@add_del");
Route::get("addressupdate","order\OrderController@addressupdate");
Route::post("address_update","order\OrderController@address_update");


Route::get("cate","cate\cateController@cate");
Route::post("cateadd","cate\cateController@cateadd");